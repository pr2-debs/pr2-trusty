#!/bin/sh
. /etc/ros/setup.sh
exec rosrun "$@"
