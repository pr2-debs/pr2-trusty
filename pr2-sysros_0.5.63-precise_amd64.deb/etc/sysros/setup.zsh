#!/bin/zsh
CATKIN_SHELL=zsh
. /etc/sysros/setup.sh
