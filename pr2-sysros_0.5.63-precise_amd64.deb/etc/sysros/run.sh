#!/bin/sh
. /etc/sysros/setup.sh
exec rosrun "$@"
