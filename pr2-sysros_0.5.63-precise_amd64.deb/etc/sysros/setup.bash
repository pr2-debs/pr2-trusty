#!/bin/bash
CATKIN_SHELL=bash
. /etc/sysros/setup.sh
