#!/bin/sh
export ROS_HOME=/var/sysros
export ROS_MASTER_URI=http://localhost:10301
. /opt/ros/fuerte/setup.sh
