#!/bin/sh

ping -c 1 10.68.0.5