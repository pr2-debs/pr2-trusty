#!/bin/sh

ping -c 1 10.68.255.1