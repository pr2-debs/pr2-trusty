Place .app files for locally installed apps here.
